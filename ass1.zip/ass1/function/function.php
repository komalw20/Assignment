<?php
ini_set('display_errors','1'); // Ye errors show karta hai esse pata chal jayega kya galti kar rahe homo
session_start();
function getPDOObject()
	{
		$host = 'localhost';
		$db   = 'komalprojects';
		$user = 'root';
		$password = '';
		

		$dsn = "mysql:host=$host;dbname=$db;charset=UTF8";

			try {
				$pdo = new PDO($dsn, $user, $password);

				if ($pdo) {
					return $pdo;
				}
			} catch (PDOException $e) {
				echo $e->getMessage();
			}
	}

	function check_login()
	{
       if(!isset($_SESSION['id'])) 
       {
           header("location:login.php");
       }
	}

	function check_session()
	{
		if(!isset($_SESSION['id']))
		{
			// redirect to login page
			header("location:login.php");exit();
		}
	}

	function login_me()
	{

		  $pdo = getPDOObject();
		   extract($_POST);  
		    $check = $pdo->prepare("SELECT * FROM users WHERE email=? AND password=?");
		    $check->execute([$email,$password]);
		    $numCount = $check->rowCount(); // yadi koi milti hai to andar jayega nahi to eror mesage
		    if($numCount > 0)
		    {
		        $rowData = $check->fetch(PDO::FETCH_ASSOC);
		        $_SESSION['id']= $rowData['id']; // phpne kar lo
		        $_SESSION['email'] = $rowData['email'];
		       // ab ye valid usr hai to ese ab index page pe bhej denge//
		        header("location:index.php");
		       
		         die();


		    }else{
		        $umessage = '<div class="alert alert-danger">Sorry ! Invalid credential</div>';
		    }

        return $umessage;
	}
?>