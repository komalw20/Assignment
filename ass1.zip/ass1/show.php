<?php
ini_set('display_errors','1'); 
$dsn = "mysql:host=localhost; dbname=reso;";
	$db_user = "root";
	$db_password = "";

	try 
	{
		//create coonection
		$con= new PDO($dsn, $db_user, $db_password );

		//SET ERROR MODE
		$con->setAttribute(PDO::ATTR_ERRMODE , PDO::ERRMODE_EXCEPTION);
		echo "Connected <hr><br>";

	}
		catch (PDOException $e) {
		echo "Coonection failed" .$e->getMessage();
	}

	
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Fetching Data From Table</title>
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	<?php include_once 'includes/head_css.php';?>
</head>
<body>
<div class="container">
	 <div class="row">
   		<div class="col-md-12 mt-4">
	   	  <div class="card">
				  <h5 class="card-header">Records</h5>
				  <div class="card-body">
				   <table class="table table-hover">
					  <thead>
					    <tr>
					      <th scope="col"> Name</th>
					      <th scope="col">Payment Amount</th>
					      <th scope="col">GST</th>
					      <th scope="col">Totalpayment Amount</th>
					      <th scope="col">Date</th>
					    </tr>
					  </thead>
					  <?php
						  $sql = "SELECT * FROM tbluser";
						  $result = $con->query($sql);
							if ($result->rowCount() > 0) 
							{
								 
										while($row = $result->fetch(PDO::FETCH_ASSOC))
		                    {
					  		?>
							    <tr>
							      
							      <td><?=$row['name']?></td>
							      <td><?=$row['payment_amt']?></td>
							      <td><?=$row['is_gst']?></td>
							      <td><?=$row['totalpay_amt']?></td>

							      
							      <td><?=date('M d,Y h:i A',strtotime($row['payment_date']));?></td>
							      <td>
							      	<a href="update.php?id=<?=$row['id']?>&data_role=update"><i class="fa fa-edit"></i></a>&nbsp;/&nbsp;
							      	<a href="?del_id=<?=$row['id']?>" title="Delete the record"><i class="fa fa-trash"></i></a>
							      </td>
							    </tr>
			    <?php
                     }
                    }
				?>
					  </tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>