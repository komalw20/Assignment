<?php
ini_set('display_errors','1'); 
$dsn = "mysql:host=localhost; dbname=reso;";
	$db_user = "root";
	$db_password = "";

	try 
	{
		//create coonection
		$con= new PDO($dsn, $db_user, $db_password );

		//SET ERROR MODE
		$con->setAttribute(PDO::ATTR_ERRMODE , PDO::ERRMODE_EXCEPTION);
		echo "Connected <hr><br>";

		//Checking gst
		if(isset($_POST['submit'])){
	     extract($_POST);
		    if($is_gst == 'yes'){
		    $totalpay_amt = $payment_amt  + (($payment_amt * 18)/100);
			}
			else{
			  $totalpay_amt  = $payment_amt ;
			}

			//Insert data  //
			// checking 4 empty filed
			if (($_REQUEST['name'] =="") || ($_REQUEST['payment_amt'] =="")|| ($_REQUEST['is_gst'] =="")) {
				echo "Fill the data..<hr><br>";
			}
			else{
				
				$name = $_REQUEST['name'];
				$payment_amt = $_REQUEST['payment_amt'];
				$is_gst = $_REQUEST['is_gst'];
			//	$totalpay_amt = $_REQUEST['totalpay_amt'];

				//insert query
$sql = "INSERT INTO tbluser (name,payment_amt,is_gst,totalpay_amt)VALUES('$name','$payment_amt','$is_gst','$totalpay_amt')";
				$affected_row = $con->exec($sql);
				echo $affected_row ."Row Inserted <br>";

				header("location:show.php");
			}


		}
		
	}
		catch (PDOException $e) {
		echo "Coonection failed" .$e->getMessage();
	}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Assignment</title>

	<link rel="stylesheet" type="text/css" href="assets/css/style.css">

	<?php include_once 'includes/head_css.php';?>
</head>
<body>
<section class="pt-5 pb-5">
	<div class="container-fluid" style="width: 400px; margin-top:50px;">
		<div class="card">
		  <div class="card-header">
		    <b><center>User Infromation</center></b>
		  </div>
		  <div class="card-body">
		   		<div class="w3-container"><!-- form design-->
					 	<form action="" method="POST"  enctype="multipart/form-data">
					      	 	<td><b>Name</b></td>
					    		<input type="text" name="name" class="form-control" />
					    		 <br>

					    		<td><b>Payment Amount</b></td>
								<input type="number" name="payment_amt" class="form-control" />
								 <br>

								<td><b>GST on Payment</b></td>
								<input type="radio" name="is_gst" value="yes" ><label>Yes</label>
								<input type="radio" name="is_gst" value="no" ><label>No</label>

								<br>  

								 <button type="submit" class="btn btn-primary" name="submit" id="submit">Submit</button>
		       
						</form>
				</div>
		  </div>
		</div>
	</div>
</section>
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
</body>
</html>

<?php  $con = "null";?>